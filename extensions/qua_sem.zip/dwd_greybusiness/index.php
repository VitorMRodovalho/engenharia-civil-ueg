<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
// needed to seperate the ISO number from the language file constant _ISO
$iso = explode( '=', _ISO );
// xml prolog
echo '<?xml version="1.2" encoding="'. $iso[1] .'"?' .'>';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
if ( $my->id ) {
	initEditor();
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php mosShowHead(); ?>
<link rel="stylesheet" type="text/css" href="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/css/template_css.css" />
<style type="text/css">
<!--
body {
	margin-left: 2px;
	margin-top: 10px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<SCRIPT LANGUAGE="JavaScript">
function addBookmark(title,url) {

  var msg_netscape = "NetScape message";
  var msg_opera    = "This function does not work with this version of Opera.  Please bookmark us manually.";
  var msg_other    = "Your browser does not support automatic bookmarks.  Please bookmark us manually.";
  var agt          = navigator.userAgent.toLowerCase();


  if (agt.indexOf("opera") != -1) 
  {
    if (window.opera && window.print)
    {
      return true;
    } else 
    {
      alert(msg_other);
    }
  }    
  else if (agt.indexOf("firefox") != -1) window.sidebar.addPanel(title,url,"");
  else if ((agt.indexOf("msie") != -1) && (parseInt(navigator.appVersion) >=4)) window.external.AddFavorite(url,title); 
  else if (agt.indexOf("netscape") != -1) window.sidebar.addPanel(title,url,"")         
  else if (window.sidebar && window.sidebar.addPanel) window.sidebar.addPanel(title,url,""); 
  else alert(msg_other);
  
}
</SCRIPT>
</head>
<body>

<table width="100%"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%"  height="82" valign="top" >
    <div align="left">&nbsp;<span class="pathway">
      <?php mosPathWay(); ?>
    </span></div></td>
    <td width="100%"><div align="right"><img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/logo_top.png" /></div></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="154" valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td height=""><img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/top_grey.png" /></td>
        </tr>
        <tr>
          <td height="16" bgcolor="#E4E4E4"><div align="center"><span class="createdate"><a href="index.php"><img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/home_noir.gif" border="0" align="absmiddle" alt="Home"/></a>&nbsp;&nbsp;<img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/dotvertical.gif" width="9" height="16" align="absmiddle" />&nbsp;&nbsp;<a href="#" onclick="javascript:window.print();"><img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/print_noir.gif" border="0" align="absbottom" alt="Print"/></a>&nbsp;&nbsp;<img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/dotvertical.gif" width="9" height="16" align="absmiddle" /></span>&nbsp;&nbsp;<span class="createdate"><a href="javascript:;" onClick="addBookmark('<?php echo $mainframe->getPageTitle(); ?>',top.location.href)"><img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/bookmark_noir.gif" border="0" align="absbottom" alt="Bookmark"/></a></span></div></td>
        </tr>
        <tr>
          <td height="22" valign="top" bgcolor="#E4E4E4"><div align="center">
            <table width="50%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td><div align="center">
                  <?php mosLoadModules ( 'user4', -1 ); ?>
                </div></td>
              </tr>
            </table>
          </div></td>
        </tr>
        <tr>
          <td><img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/bottom_grey.png" /></td>
        </tr>
	  </table>    
      <table width="100%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td><?php mosLoadModules ( 'left' ); ?>
              <div align="center"></div></td>
        </tr>
      </table>
      <table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="100%">
            <?php mosLoadModules ( 'user1' ); ?></td>
        </tr>
      </table>
      <table width="100%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#E4E4E4" class="bottom"><div align="left">
              <?php mosLoadModules ( 'inset' ); ?>
          </div></td>
        </tr>
      </table>
    <td width="100%" valign="top"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
	  <td>
	  <table align="right" width="100%">
	  	<tr>
        <td background="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/dot.gif"><img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/pixel.png" width="1" height="1" /></td>
		</tr>
	  </table>
	  </td>
      </tr>	
      <tr>
        <td valign="top">
		<?php if ( $option == "" || $option == "com_frontpage" ) { ?>
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td>&nbsp; </td>
              <td><div align="right"><img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/splash.gif" /></div></td>
            </tr>
          </table>
		 <?php } ?> 
          <div align="center">
            <?php mosLoadModules ( 'banner, -1' ); ?>
          </div></td>
      </tr>
    </table>
      <table width="100%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td valign="top"><table width="96%" border="0" align="center" cellpadding="4" cellspacing="0">
            <tr>
              <td valign="top" class="mainpage"><?php mosLoadModules ( 'top' ); ?></td>
            </tr>
          </table>
            <table width="96%" border="0" align="center" cellpadding="4" cellspacing="0">
              <tr>
                <td valign="top" class="mainpage"><?php mosMainBody(); ?>
                </td>
              </tr>
            </table>
            <table width="96%" border="0" align="center" cellpadding="4" cellspacing="0">
              <tr>
                <td width="33%" valign="top" class="mainpage">                <?php mosLoadModules ( 'user5' ); ?></td>
                <td width="33%" valign="top" class="mainpage"><?php mosLoadModules ( 'user6' ); ?></td>
                <td width="33%" valign="top" class="mainpage"><?php mosLoadModules ( 'user7' ); ?></td>
              </tr>
            </table>
            <table width="96%" border="0" align="center" cellpadding="4" cellspacing="0">
              <tr>
                <td valign="top" class="mainpage"><?php mosLoadModules ( 'bottom' ); ?></td>
              </tr>
          </table></td>
			<?php if (mosCountModules( "right" )) { ?>
          <td width="154" valign="top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td valign="top"><?php mosLoadModules ( 'right' ); ?>
                  <?php mosLoadModules ( 'user2' ); ?></td>
            </tr>
			<?php } ?>
          </table>
		  </td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td colspan="2" valign="top">  <div align="center">
    </div>      </tr>
</table>
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td background="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/dot.gif"><img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/pixel.png" width="1" height="3" /></td>
  </tr>
  <tr>
    <td valign="middle"><div align="center"></div>
    <table width="100%"  border="0" align="left" cellpadding="0" cellspacing="0">
      <tr>
        <td width="42%" valign="top"><div class="smalldark" align="center">&nbsp;&nbsp;<img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/home_noir.gif" width="12" height="10" align="bottom" />&nbsp;<a href="index.php"><font color="#000000">Home</font></a> <img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/dotvertical.gif" width="9" height="16" align="absmiddle" />&nbsp;<img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/print_noir.gif" width="15" height="16" align="absbottom" /><a href="#" onclick="javascript:window.print();"><font color="#000000">Print</font></a> <img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/dotvertical.gif" width="9" height="16" align="absmiddle" />&nbsp;<font color="#000000">@</font> <a href="index.php?option=com_contact&Itemid=3"><font color="#000000">Contact</font></a> <img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/dotvertical.gif" width="9" height="16" align="absmiddle" /> <img src="<?php echo $mosConfig_live_site; ?>/templates/dwd_greybusiness/images/top_noir.gif" align="absbottom" /><a href="#"><font color="#000000">Top</font></a><br />
              <br />
        </div></td>
        <tr> 
    <td align="center" valign="middle">
      <?php include_once('includes/footer.php'); ?>
    </td>
  </tr>
  </table></td>
	<tr align="center"><td> Desenvolvido por: <a href="http://www.grinfoart.com" >GR InfoArt (Vitor Maia)</a> e <a href="#">Marcell F�vio</a></td></tr>
</td>
</table>
<?php mosLoadModules( 'debug', -1 );?>
</body>
</html>