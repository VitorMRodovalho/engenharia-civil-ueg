Pour un utilisation optimum de ce template, il est recommand� de suivre les instructions suivantes:

- Charger le(s) menu(s) dans la position "left" sans le titre

- Charger les autres modules dans la position "left" avec ou sans titre

- La position "Inset" b�n�ficie d'un arri�re-plan gris.

- Ce template poss�de une position "right" mais cela n'est pas tr�s "esth�tique".

- Les autres modules � gauche peuvent �tre positionn�s dans "user1", "inset"

- Les autres modules � droite peuvent �tre positionn�s dans "user2", "right"

- L'image "Splash" de la page d'accueil n'apparait pas dans les autres pages

- Le module "Banner" se situe en dessous de l'image "Spalsh" viennent ensuite les modules "Top" et "mainbody",

- Puis une s�rie de trois modules sur la largeur, "user5", "user6", "user7", puis enfin la position "bottom"



NOTA BENE : Ce template n'utilise pas de menu haut (user3, -1)